Grammar Police will only look for push files 01-08 and release files 01-06.
If you want custom sound, you must REPLACE these existing wav files.

Special thanks to BenH, FTW Flamez, Wikd, and Gaming With Cookies