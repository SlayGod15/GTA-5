OCRP: https://forum.cfx.re/t/release-ocrp-community-releases/166277
Priest0802: https://forum.cfx.re/t/release-original-street-names-w-postal-numbers/8717
Virus_City: https://forum.cfx.re/t/release-postal-code-map-minimap-new-improved-v1-2/147458

Nearest Postal by BlockBa5her: https://forum.cfx.re/t/release-nearest-postal-script/293511