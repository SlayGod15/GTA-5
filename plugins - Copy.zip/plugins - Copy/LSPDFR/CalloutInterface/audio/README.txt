MDT_01 through MDT_07 are from Windows 98 and were obtained here:  
http://www.mscs.mu.edu/~mikes/174/demos/Win98sounds/

MDT_08.wav was provided by LT. Shadow Wolf